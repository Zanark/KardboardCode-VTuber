---
title: "Command Reference"
description: "Environment setup, model downloads, runtime modes, privacy flags, and quality checks."
---

# Command reference

## Native desktop studio

From `C:\devdesk\homedesk\KardboardCode\KardboardCode-VTuber`:

```powershell
.\.venv312\Scripts\python.exe -m pip install -e ".[dev,tracking,virtual-camera,gui]"
.\.venv312\Scripts\python.exe -m kardboard_vtuber.gui
```

Use `--demo` for the synthetic, camera-free demonstration or `--preset "C:\path\studio.json"` to
load source-free controls without starting capture. The GUI entry point is
`.\.venv312\Scripts\kardboard-studio.exe`; existing valid camera commands remain supported,
including zero-duration CLI probes. The new per-eye overrides are opt-in.

The native interface includes all camera flags below, model verification/download, guided/free
private recording, and a built-in **Tutorial**. Read the
[complete walkthrough](../09-desktop-studio/tutorial.md).

Independent eye overrides are also available directly:

```powershell
$env:KARDBOARD_CAMERA_URL = Read-Host "Paste your current camera source"
.\.venv312\Scripts\python.exe -m kardboard_vtuber `
  --source $env:KARDBOARD_CAMERA_URL `
  --physics --mirror `
  --left-blink-threshold 0.30 `
  --right-blink-threshold 0.40
```

Each override falls back to `--blink-threshold` when omitted. Effective blink values must be
lower than both `--eye-open-threshold` and `--wink-threshold`. In the GUI these values, relative
wink tuning, action hold times and brightness are live. Other settings unlock after Stop.

```mermaid
flowchart LR
    Source["Camera or recording"] --> Base["Base preview"]
    Base --> Debug["--tracking-debug"]
    Base --> Avatar["--render-cardboard or --physics"]
    Avatar --> Body["--full-body"]
    Avatar --> Hands["--hand-occlusion"]
    Base --> Green["--green-screen"]
    style Source fill:#2d333b,stroke:#6d5dfc,color:#e6edf3
    style Base fill:#1c2333,stroke:#6d5dfc,color:#e6edf3
    style Debug fill:#2d333b,stroke:#6d5dfc,color:#e6edf3
    style Avatar fill:#2d333b,stroke:#6d5dfc,color:#e6edf3
    style Body fill:#2d333b,stroke:#6d5dfc,color:#e6edf3
    style Hands fill:#2d333b,stroke:#6d5dfc,color:#e6edf3
    style Green fill:#2d333b,stroke:#6d5dfc,color:#e6edf3
```

## Environment

```powershell
cd C:\devdesk\homedesk\KardboardCode\KardboardCode-VTuber
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

## Local camera

```powershell
python -m kardboard_vtuber --source 0 --backend auto --mirror
```

Tracker inputs receive a mild brightness lift of `12`; the displayed and OBS-captured preview
retains the original camera brightness. Override internal processing with `--brightness 0..100`,
for example `--brightness 20` in a darker room.

## Android IP Webcam

```powershell
python -m kardboard_vtuber `
  --source "http://USERNAME:PASSWORD@PHONE_IP:8080/video" `
  --backend auto `
  --rotate left `
  --mirror
```

## Headless benchmark

```powershell
python -m kardboard_vtuber `
  --source "http://USERNAME:PASSWORD@PHONE_IP:8080/video" `
  --backend auto `
  --rotate left `
  --mirror `
  --headless `
  --duration 30
```

## Direct virtual camera for calling apps (Windows)

Install OBS Studio once for its camera component. The OBS application can remain closed:

```powershell
.\.venv312\Scripts\python.exe -m pip install -e ".[tracking,virtual-camera]"
$env:KARDBOARD_CAMERA_URL = Read-Host "Paste your full camera stream URL"
.\.venv312\Scripts\python.exe -m kardboard_vtuber `
  --source $env:KARDBOARD_CAMERA_URL `
  --mirror `
  --physics `
  --tracking-width 1280 `
  --brightness 30 `
  --virtual-camera
```

Set `KARDBOARD_CAMERA_URL` in the same PowerShell terminal before running; session assignments
do not carry over to new terminals. Then select **OBS Virtual Camera** in Discord, Teams,
Meet, or another camera-capable app. Stop any other producer of that device, including OBS's
**Start Virtual Camera** output. There is only one OBS camera instance; this mode does not install
or rename a driver. It uses [pyvirtualcam](https://github.com/letmaik/pyvirtualcam#supported-virtual-cameras)
to send composed frames directly.

`--virtual-camera` enables cardboard rendering and face tracking even without `--physics`.
`--headless` suppresses local windows, not rendering or camera delivery. Only the clean composite
is sent; all local debug overlays and the opt-in raw-face preview are excluded. In face-only
mode, startup is black and lost or stale face tracking freezes the last safe frame. Capture interruptions repeat that
composite, never the unprocessed input. `--brightness` does not brighten exported video.

| Option | Default | Meaning |
|---|---|---|
| `--virtual-camera-width` | `1280` | Fixed output width, positive even number |
| `--virtual-camera-height` | `720` | Fixed output height, positive even number |
| `--virtual-camera-fps` | `30` | Advertised FPS (1-60); actual motion follows source/processing speed |

Portrait or differently shaped input is fitted with black bars. Changes to capture resolution do
not change the camera's output format mid-call. `--preview-height` affects only the local window.
Microphone audio remains a separate device. If the device is missing, check OBS's camera-component
installation and restart the calling app; app permissions or managed-device policies may also
restrict camera access.

## Recorded calibration video

Local video files are automatically paced at their recorded FPS and stop cleanly at EOF.
The guided recording is already upright and mirrored:

```powershell
python -m kardboard_vtuber `
  --source "C:\path\to\KardboardCode-tracking-calibration-guided-45s.mp4" `
  --input-already-mirrored `
  --render-cardboard `
  --cardboard-renderer textured-3d
```

Do not add `--rotate left` or `--mirror` for this recording. Use
`--cardboard-renderer procedural-2d` to compare the preserved original prototype.

## Record a new canonical regression video

```powershell
python scripts\record_guided_regression.py `
  --source "http://YOUR_USERNAME:YOUR_PASSWORD@PHONE_IP:8080/video" `
  --backend auto `
  --rotate left `
  --mirror `
  --brightness 12 `
  --preview-height 720 `
  --output-dir "C:\path\to\private-regression-output" `
  --name "KardboardCode-canonical-regression"
```

Follow the 12 on-screen stages. The clean MP4 and synchronized CSV receive the same timestamp.

## Optional raw-face debug panel

The standard preview is clean by default. Add `--tracking-debug` to show the synthetic face-mesh
inset, pose axes, action state, tracked pose values, FPS, resolution, and frame-age text. This does
not expose raw face pixels.

The raw face panel is disabled by default because it reveals the user's face. Enable it only for
local debugging:

```powershell
python -m kardboard_vtuber `
  --source "http://YOUR_USERNAME:YOUR_PASSWORD@PHONE_IP:8080/video" `
  --backend auto `
  --rotate left `
  --mirror `
  --render-cardboard `
  --debug-face-preview `
  --preview-height 900
```

`--preview-height` changes only the displayed window size. Capture, tracking, and rendering remain
at the source resolution and retain the full camera frame.

## Tune blink and wink sensitivity

The default calibrated thresholds are:

| Option | Default | Meaning |
|---|---:|---|
| `--blink-threshold` | `0.35` | Both eyes at or below this value count as closed |
| `--wink-threshold` | `0.70` | The winked eye must be at or below this value |
| `--eye-open-threshold` | `0.65` | The opposite eye must be at or above this value |
| `--wink-min-difference` | `0.15` | Minimum openness difference between the eyes |

For fewer false blinks and winks, start with:

```powershell
--blink-threshold 0.20 `
--wink-threshold 0.50 `
--eye-open-threshold 0.72 `
--wink-min-difference 0.25
```

Lower closed-eye thresholds are less sensitive. Higher open-eye and difference requirements make
winks stricter. Values must remain between `0` and `1`; the blink threshold must remain below both
the open-eye and wink thresholds. The same settings drive action logs and the visible K/C state.
If brief noise still survives, also raise `--eye-action-hold-ms` from `40` to `60` or `80`.

## Full-body avatar and skeleton

Download and verify the official MediaPipe Pose Landmarker Lite model:

```powershell
python scripts\download_pose_landmarker_model.py
```

Then enable the feature:

```powershell
python -m kardboard_vtuber `
  --source "******PHONE_IP:8080/video" `
  --backend auto `
  --rotate left `
  --mirror `
  --full-body `
  --preview-height 900
```

`--full-body` automatically enables face tracking and cardboard rendering. A separate
`KardboardCode Full Body Skeleton` window shows the 33 numbered pose landmarks and line
connections on black. The skeleton is not filled or composited into the camera preview. The
tracker supports one person and can only track body parts visible in the camera frame.

To keep only the cardboard head moving when the face turns away, use:

```powershell
python -m kardboard_vtuber `
  --source "YOUR_CAMERA_URL" `
  --rotate left `
  --mirror `
  --body-head-fallback
```

`--body-head-fallback` automatically enables cardboard, face, and pose tracking but does not
render the synthetic body or open the skeleton window. While the face is visible, it learns the
relationship between the face and shoulders. During face loss, it uses confident shoulder
landmarks to estimate head position, size, roll, and continuing yaw with neutral expressions. If
the initial calibration has not completed or the shoulders are also lost, rendering falls back to
the existing frozen privacy-safe frame. To protect preview performance, fallback-only pose
tracking runs at no more than 256-pixel input and 8 FPS; `--full-body` retains the requested pose
resolution and unrestricted submission rate.

Begin the session facing the camera normally for about one second. The fallback deliberately
refuses to invent a generic head size until it has collected enough paired face-and-shoulder
observations. During that startup period, the preview keeps the lower body visible, blacks out
everything above the detected shoulders, and displays calibration progress. If body pose is not
available either, the entire camera image remains opaque behind the instructions.

For the colour-square hood:

```powershell
python -m kardboard_vtuber `
  --source $env:KARDBOARD_CAMERA_URL `
  --mirror `
  --physics `
  --hood-marker-tracking `
  --tracking-debug
```

The marker tracker recognizes green on the wearer's anatomical left and blue on the anatomical
right. Red and pink are ignored. Face plus body tracking selects front view; body tracking without
face tracking or either side marker selects rear view. Side markers preserve the latest
face/body-derived head dimensions to prevent the cardboard box from enlarging during profile
turns. `--tracking-debug` outlines accepted squares and prints marker state.

## Enable flap hinge physics

```powershell
python -m kardboard_vtuber `
  --source "YOUR_CAMERA_URL" `
  --backend auto `
  --rotate left `
  --mirror `
  --physics `
  --preview-height 900
```

`--physics` automatically enables face tracking and the textured 3D cardboard renderer. Both
inward underside flaps and the broad front underside flap receive separate bounded damped-spring
hinges driven by sustained tracked head turns, tilt, and movement. The two external side tabs use
wider, highly yaw-sensitive hinges for obvious left-right secondary motion. The internal opaque
privacy volume remains static.

The textured model is moved slightly backward in perspective by default. Add
`--box-depth-offset 0` to restore the previous Z position. Positive offsets have no upper cap;
large values can make the projected box too small to preserve head coverage.

## Green-screen the camera background

Download and verify the official MediaPipe Selfie Segmenter model:

```powershell
python scripts\download_selfie_segmenter_model.py
```

Then add `--green-screen` to the normal camera command. Person pixels remain visible and all
background pixels become pure chroma green for OBS. The compositor fails closed to a fully green
frame before the first mask or whenever the latest mask becomes stale.

## Privacy-safe hand occlusion

Download the verified official MediaPipe model once:

```powershell
python scripts\download_hand_landmarker_model.py
```

Then add `--hand-occlusion` to the textured renderer command:

```powershell
python -m kardboard_vtuber `
  --source "http://YOUR_USERNAME:YOUR_PASSWORD@PHONE_IP:8080/video" `
  --backend auto `
  --rotate left `
  --mirror `
  --render-cardboard `
  --hand-occlusion
```

The hand tracker runs asynchronously at a 320-pixel input width and restores detected hand and
forearm pixels over the rendered avatar. This provides convincing foreground interaction when a
hand is in front, but a monocular RGB camera cannot prove depth; a hand physically behind the
avatar may also be treated as foreground.

This mode intentionally supports only the anatomical hand and forearm mask. Arbitrary held-object
occlusion is not supported by the RGB-only camera pipeline. Inferred monocular depth was tested and
removed because it could classify face pixels as foreground and violate fail-closed privacy.
Reliable general-object occlusion requires an aligned hardware/AR depth stream.

```mermaid
%%{init: {"theme": "base", "themeVariables": {"primaryColor": "#2d333b", "primaryBorderColor": "#6d5dfc", "primaryTextColor": "#e6edf3", "lineColor": "#8b949e", "secondaryColor": "#161b22", "tertiaryColor": "#2d333b"}}}%%
stateDiagram-v2
    [*] --> CameraPreview
    CameraPreview --> Black: face renderer has no safe acquisition
    CameraPreview --> AvatarVisible: face renderer has valid state
    AvatarVisible --> FrozenSafeFrame: face tracking becomes stale
    CameraPreview --> FullyGreen: green screen lacks a fresh mask
    FullyGreen --> PersonOnGreen: fresh person mask arrives
```

## Quality checks

```powershell
python -m ruff check .
python -m pytest
git --no-pager diff --check
```

## Regenerate the face-free documentation gallery

```powershell
python scripts\generate_documentation_gallery.py
```

This recreates the expanded angle, scenario, performance, flap-motion, surface-tour, tracking
debug, body-skeleton, and render-mesh sheets. Runtime debug functions receive synthetic landmarks,
and every other image uses the runtime mesh on a solid dark background. The script never reads a
camera frame.

## Regenerate the animated README demo

```powershell
python scripts\generate_readme_animation.py `
  --telemetry "C:\path\to\private-regression.csv"
```

Only numeric tracking telemetry is read. The generated
`docs/images/kardboardcode-live-demo.gif` contains synthetic renderer output and text, never
camera frames.

## Regenerate the real-life black-hoodie demo

```powershell
python scripts\generate_real_life_animation.py `
  --video "C:\path\to\private-black-hoodie-recording.mp4" `
  --telemetry "C:\path\to\matching-private-telemetry.csv"
```

The private recording and telemetry remain outside the repository. The generator samples every
recorded calibration stage, re-detects the face bounds, applies the synchronized filtered pose and
expression values, verifies that the rendered avatar covers at least 98% of face landmarks, and
adds an opaque head-region backing before writing
`docs/images/kardboardcode-real-life-demo.gif`. The output contains the approved body and
background camera pixels, but no visible face or hairline.

Add `--green-screen` to process the same private source through person segmentation and write
`docs/images/kardboardcode-green-screen-demo.gif`:

```powershell
python scripts\generate_real_life_animation.py `
  --video "C:\path\to\private-black-hoodie-recording.mp4" `
  --telemetry "C:\path\to\matching-private-telemetry.csv" `
  --green-screen
```

Composition uses the runtime threshold, morphological cleanup, and exact BGR chroma color
`(0, 255, 0)` before GIF palette encoding.

## CLI help

```powershell
python -m kardboard_vtuber --help
```

## Backend fallback order

1. `auto`
2. `ffmpeg` for network streams
3. `dshow` for local Windows cameras
4. `msmf` for local Windows cameras

Never commit a command containing real credentials.

`Ctrl+C` requests an orderly shutdown. The capture loop exits and closes the renderer, MediaPipe
trackers, camera stream, and OpenCV windows before the process returns.

---

⬅️ [Repository map](repository-map.md) · 🏠 [Book home](../README.md)
